<?php

namespace App\Http\Controllers;

use App\Models\TypeContrat;
use Illuminate\Http\Request;;

class TypeContratController extends Controller
{
    // public function typeContrat()
    // {
    //     $types_contrat = TypeContrat::all();
    //     dd($types_contrat);
    //     return view ('admin.entreprises.create', [
    //         'types_contrat' => $types_contrat,
    //     ]);

    // }
}
