<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <img src="<?php echo e(asset('/img/logo.png')); ?>" alt="" style="width: 55px; border-radius: 5px; margin-right : 10px"><a class=" title" href="<?php echo e(route('home')); ?>">weurkheuy</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarsExampleDefault">
      <ul class="navbar-nav mr-auto">
        <?php if(Auth::user()): ?>
          <li class="nav-item active">
            <a class="entreprises" href="<?php echo e(route('entreprises')); ?>">entreprises <span class="sr-only">(current)</span></a>
          </li>
        <?php endif; ?>
        <?php if(Auth::user()): ?>
          <li class="nav-item">
            <a class="entreprises" href="<?php echo e(route('postuler')); ?>">Postuler <span class="sr-only">(current)</span></a>
          </li>
        <?php endif; ?>
      </ul>
      <?php if(Auth::user()): ?>
        <?php if(Auth::user()->role === 'ADMIN'): ?>
        <li class="nav-item">
          <a class="admin" href="<?php echo e(route('admin.entreprises')); ?>">Espace admin</a>
        </li>
        <?php endif; ?>
      <form method="POST" action="<?php echo e(route('logout')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit" class="deconnecter">Deconnexion</button>
      </form>
    <?php else: ?>
      <li class="nav-item">
        <a class="text-white connecter" href="<?php echo e(route('login')); ?>">Se connecter</a>
      </li>
      <?php endif; ?>
      
    </div>
  </nav><?php /**PATH C:\wamp64\www\LARAVEL 8\emploi et stage\emploiStage\resources\views/incs/navbar.blade.php ENDPATH**/ ?>