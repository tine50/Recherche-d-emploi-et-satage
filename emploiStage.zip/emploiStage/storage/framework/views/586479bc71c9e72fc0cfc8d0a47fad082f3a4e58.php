

<?php $__env->startSection('content'); ?>
    <div class="jumbotron">
        <?php if(Auth::user()): ?>
            <?php echo $__env->make('partials.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <h1 class=" text-center mt-5"><?php echo e($entreprise->titre); ?></h1>
        <div class="d-flex justify-content-center my-5">
            <a href="<?php echo e(route('home')); ?>" class="btn btn-primary">
                <i class="fas fa-arrow-left"></i>  Retour
            </a>
            <form action="<?php echo e(route('entreprises.postuler')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" value="<?php echo e($entreprise->id); ?>" name="entreprises_id">
                <button type="submit" class="btn btn-success">Postuler</button>
            </form>    
        </div>
        <h5 class="text-center my-3 pt-3"><?php echo e($entreprise->sous_titre); ?></h5>
        <span class="badge badge-dark"><?php echo e($entreprise->type_entreprises->nom_type_entreprise); ?></span><span class="badge bg-primary"><?php echo e($entreprise->type_contrats->nom_type_contrat); ?></span>
    </div>
    <div class="container">
        <p class="text-center">
            <?php echo $entreprise->corps; ?>

        </p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\LARAVEL 8\emploiStage\resources\views/entreprise.blade.php ENDPATH**/ ?>