<footer class="container">
    <p>Do By Abdoussalam TINE</p>
  </footer><?php /**PATH C:\wamp64\www\LARAVEL 8\emploi et stage\emploiStage\resources\views/incs/footer.blade.php ENDPATH**/ ?>